new Vue({
  el:'#vue-app',
  data:{
    name:'Almaloco',
    job:'Developer',
    website:'http://www.almaloco.com',
    websiteTag:'<a href="http://www.almaloco.com">almaloco web</a>'
  },
  methods:{
    greet:function(time){
      return 'RE-HI  Good' + time + ' ' + this.name
    }
  }
});
